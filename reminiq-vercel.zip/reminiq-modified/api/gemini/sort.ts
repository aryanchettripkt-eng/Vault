import type { VercelRequest, VercelResponse } from '@vercel/node';

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: 'GEMINI_API_KEY not configured' });
  }

  const { memories } = req.body;
  if (!memories || memories.length === 0) {
    return res.status(400).json({ error: 'Missing memories' });
  }

  try {
    const memoryContext = memories.map((m: any) => ({
      id: m.id,
      title: m.title,
      desc: m.desc,
      mood: m.mood,
      location: m.location || 'Unknown',
      date: m.date
    }));

    const response = await fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=' + apiKey, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{
          parts: [{
            text: `You are a sophisticated, nostalgic curator. Group these memories into meaningful albums.

Memories:
${JSON.stringify(memoryContext)}

Group by mood, location, or theme. Return a JSON array of album objects. Every memory must belong to exactly one album.

Each album: { "title": "Poetic short title", "memoryIds": ["id1", "id2"] }

Respond ONLY with a valid JSON array, no markdown or extra text.`
          }]
        }],
        generationConfig: { responseMimeType: 'application/json' }
      })
    });

    const data = await response.json();
    const text = data.candidates?.[0]?.content?.parts?.[0]?.text || '[]';
    const albumsData = JSON.parse(text.replace(/```json|```/g, '').trim());
    const albums = albumsData.map((a: any) => ({
      id: Math.random().toString(36).substr(2, 9),
      ...a
    }));
    return res.status(200).json(albums);
  } catch (error) {
    console.error('Gemini sort error:', error);
    return res.status(500).json([]);
  }
}
