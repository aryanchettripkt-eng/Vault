import type { VercelRequest, VercelResponse } from '@vercel/node';

export default async function handler(req: VercelRequest, res: VercelResponse) {
  const token = req.headers.authorization;
  const { q } = req.query;
  if (!token) return res.status(401).json({ error: 'No token' });

  try {
    const response = await fetch(`https://api.spotify.com/v1/search?q=${encodeURIComponent(q as string)}&type=track&limit=10`, {
      headers: { Authorization: token as string }
    });
    const data = await response.json();
    res.json(data);
  } catch (error) {
    console.error('Spotify Search Error:', error);
    res.status(500).json({ error: 'Failed to search tracks' });
  }
}
