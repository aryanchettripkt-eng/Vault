import React, { useState, useEffect, useRef, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Camera, 
  Mic, 
  Music, 
  Type, 
  X, 
  Plus, 
  Play, 
  MapPin, 
  ChevronLeft,
  Sparkles,
  Disc,
  Trash2,
  Square
} from 'lucide-react';
import { Memory, Album, DayReaction } from '../lib/gemini';
import { LOCAL_TRACKS, Track } from '../lib/music';
import AlbumDetail from './AlbumDetail';
import CalendarView from './CalendarView';
import MusicPlayer from './MusicPlayer';
import MemoryAlbum from './MemoryAlbum';

interface VaultProps {
  onBack: () => void;
  memories: Memory[];
  onAddMemory: (memory: Memory) => void;
  albums: Album[];
  onUpdateAlbums: (albums: Album[]) => void;
  onUpdateAlbumTitle: (albumId: string, newTitle: string) => void;
  onUpdateAlbum: (albumId: string, data: Partial<Album>) => void;
  dayReactions: DayReaction[];
  onUpdateDayReaction: (date: string, emoji: string) => void;
  activeOverlay: string | null;
  onCloseOverlay: () => void;
  onSortAlbums: () => void;
  isSorting: boolean;
  isAddModalOpen: boolean;
  onSetIsAddModalOpen: (open: boolean) => void;
  prefilledDate: string | null;
  onClearPrefilledDate: () => void;
  googleToken: string | null;
  googlePhotos: any[];
  isFetchingPhotos: boolean;
  onConnectGoogle: () => void;
  onFetchPhotos: (token: string) => void;
  spotifyToken: string | null;
  onConnectSpotify: () => void;
}

export default function Vault({ 
  onBack, 
  memories, 
  onAddMemory, 
  albums, 
  onUpdateAlbums, 
  onUpdateAlbumTitle,
  onUpdateAlbum,
  dayReactions,
  onUpdateDayReaction,
  activeOverlay,
  onCloseOverlay,
  onSortAlbums,
  isSorting,
  isAddModalOpen,
  onSetIsAddModalOpen,
  prefilledDate,
  onClearPrefilledDate,
  googleToken,
  googlePhotos,
  isFetchingPhotos,
  onConnectGoogle,
  onFetchPhotos,
  spotifyToken,
  onConnectSpotify
}: VaultProps) {
  const [selectedMemory, setSelectedMemory] = useState<Memory | null>(null);
  const [sortBy, setSortBy] = useState<'newest' | 'oldest'>('newest');

  // Spotify state
  const [spotifyTracks, setSpotifyTracks] = useState<any[]>([]);
  const [isSearchingSpotify, setIsSearchingSpotify] = useState(false);
  const [spotifySearchQuery, setSpotifySearchQuery] = useState('');
  const [musicSource, setMusicSource] = useState<'local' | 'spotify'>('local');
  const [selectedLocalTrack, setSelectedLocalTrack] = useState<Track | null>(null);

  // Form state
  const [newType, setNewType] = useState<Memory['type']>('photo');
  const [newTitle, setNewTitle] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newMood, setNewMood] = useState('joy');
  const [newLocation, setNewLocation] = useState('');
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  
  // Voice Recording state
  const [isRecording, setIsRecording] = useState(false);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  // Music state
  const [newSong, setNewSong] = useState('');
  const [newArtist, setNewArtist] = useState('');
  const [newDate, setNewDate] = useState(new Date().toISOString().split('T')[0]);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];
      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) audioChunksRef.current.push(e.data);
      };
      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/wav' });
        const url = URL.createObjectURL(audioBlob);
        setAudioUrl(url);
      };
      mediaRecorder.start();
      setIsRecording(true);
    } catch (err) {
      console.error("Error accessing microphone:", err);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      mediaRecorderRef.current.stream.getTracks().forEach(track => track.stop());
    }
  };

  const deleteRecording = () => {
    setAudioUrl(null);
    audioChunksRef.current = [];
  };

  const sortedMemories = useMemo(() => {
    return [...memories].sort((a, b) => {
      const dateA = new Date(a.date).getTime();
      const dateB = new Date(b.date).getTime();
      return sortBy === 'newest' ? dateB - dateA : dateA - dateB;
    });
  }, [memories, sortBy]);

  const searchSpotify = async (q: string) => {
    if (!spotifyToken || !q) return;
    setIsSearchingSpotify(true);
    try {
      const response = await fetch(`/api/spotify/search?q=${encodeURIComponent(q)}`, {
        headers: { Authorization: `Bearer ${spotifyToken}` }
      });
      const data = await response.json();
      setSpotifyTracks(data.tracks?.items || []);
    } catch (error) {
      console.error('Spotify Search Error:', error);
    } finally {
      setIsSearchingSpotify(false);
    }
  };

  useEffect(() => {
    if (prefilledDate) {
      setNewDate(prefilledDate);
      setNewType('photo');
    }
  }, [prefilledDate]);

  const handleSave = () => {
    const emotions = ['happy', 'nostalgic', 'melancholic', 'peaceful'];
    const mockEmotion = emotions[Math.floor(Math.random() * emotions.length)];
    const mockTranscript = newType === 'voice' ? "This is a mock transcription of your beautiful voice memory..." : undefined;

    const mem: Memory = {
      id: Math.random().toString(36).substr(2, 9),
      type: newType,
      title: newTitle || 'Untitled Moment',
      desc: newDesc,
      mood: newMood,
      location: newLocation,
      date: new Date(newDate).toISOString(),
      photoUrl: photoPreview || undefined,
      audioUrl: audioUrl || undefined,
      musicUrl: newType === 'music' ? (musicSource === 'local' ? selectedLocalTrack?.url : undefined) : undefined,
      transcript: mockTranscript,
      emotion: mockEmotion,
      music: newSong ? {
        song: newSong,
        artist: newArtist,
        albumArt: photoPreview || `https://picsum.photos/seed/${newSong}/300/300`
      } : undefined
    };
    onAddMemory(mem);
    onSetIsAddModalOpen(false);
    onClearPrefilledDate();
    setNewTitle(''); setNewDesc(''); setNewLocation(''); setPhotoPreview(null);
    setAudioUrl(null); setNewSong(''); setNewArtist('');
  };

  return (
    <div className="fixed inset-0 z-50 bg-warm-white overflow-hidden">
      <div className="film-grain" />

      {/* Background texture */}
      <div className="absolute inset-0 pointer-events-none" style={{
        background: 'radial-gradient(ellipse at 30% 20%, rgba(232,216,144,0.18) 0%, transparent 50%), radial-gradient(ellipse at 70% 80%, rgba(201,160,160,0.15) 0%, transparent 50%)'
      }} />

      {/* Top Bar */}
      <div className="fixed top-0 left-0 right-0 z-[1000] px-6 py-4 flex items-center justify-between bg-gradient-to-b from-warm-white/95 to-transparent backdrop-blur-sm">
        <button 
          onClick={onBack}
          className="flex items-center gap-2 font-hand text-brown/70 hover:text-dark-brown transition-colors"
        >
          <ChevronLeft size={18} />
          back
        </button>
        <div className="flex gap-3">
          <div className="flex bg-parchment/80 border border-light-brown/20 rounded-full p-0.5 backdrop-blur-md shadow-sm">
            <button 
              onClick={() => setSortBy('newest')}
              className={`px-3 py-1 rounded-full font-hand text-xs transition-all ${sortBy === 'newest' ? 'bg-brown text-cream' : 'text-brown hover:bg-brown/10'}`}
            >
              Newest
            </button>
            <button 
              onClick={() => setSortBy('oldest')}
              className={`px-3 py-1 rounded-full font-hand text-xs transition-all ${sortBy === 'oldest' ? 'bg-brown text-cream' : 'text-brown hover:bg-brown/10'}`}
            >
              Oldest
            </button>
          </div>
          <button 
            onClick={() => onSortAlbums()}
            disabled={isSorting}
            className="bg-sage/20 border border-sage/30 text-moss font-hand text-sm px-4 py-1.5 rounded-full hover:bg-sage/30 transition-all backdrop-blur-md shadow-sm flex items-center gap-2 disabled:opacity-50"
          >
            {isSorting ? (
              <span className="animate-pulse">Sorting...</span>
            ) : (
              <>
                <Sparkles size={14} />
                AI Albums
              </>
            )}
          </button>
        </div>
      </div>

      {/* Main Memory Album — replaces Three.js canvas */}
      <div className="h-full overflow-y-auto pt-20 pb-28 px-4 flex flex-col items-center justify-center">
        <MemoryAlbum
          memories={sortedMemories}
          onSelectMemory={setSelectedMemory}
        />
      </div>

      {/* Add FAB */}
      <button 
        onClick={() => onSetIsAddModalOpen(true)}
        className="fixed bottom-6 right-6 z-[1000] w-14 h-14 bg-moss border-[1.5px] border-light-brown rounded-full flex items-center justify-center text-2xl text-parchment shadow-2xl hover:scale-110 transition-transform"
      >
        <Plus />
      </button>

      {/* Add Modal */}
      <AnimatePresence>
        {isAddModalOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[5000] flex items-center justify-center bg-cream/75 backdrop-blur-xl p-5"
          >
            <motion.div 
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              className="bg-warm-white border border-light-brown/20 rounded-[4px] p-9 max-w-[540px] w-full max-h-[90vh] overflow-y-auto relative shadow-2xl"
            >
              <button onClick={() => { onSetIsAddModalOpen(false); onClearPrefilledDate(); }} className="absolute top-4 right-4 text-brown/40 hover:text-dusty-rose"><X size={20} /></button>
              <h2 className="font-serif text-2xl text-dark-brown italic mb-1.5">New Journal Entry</h2>
              <p className="font-hand text-sm text-brown/50 mb-7">✦ what kind of moment is this? ✦</p>
              
              <div className="flex gap-2 flex-wrap mb-6">
                {(['photo', 'voice', 'text', 'music'] as const).map(t => (
                  <button 
                    key={t}
                    onClick={() => setNewType(t)}
                    className={`px-4 py-1.5 rounded-full font-hand text-sm border transition-all ${newType === t ? 'bg-sage/20 border-sage text-moss' : 'bg-parchment/30 border-light-brown/20 text-brown/60'}`}
                  >
                    {t === 'photo' ? '📷 Photo' : t === 'voice' ? '🎙 Voice' : t === 'text' ? '✍️ Story' : '🎵 Music'}
                  </button>
                ))}
              </div>

              {newType === 'photo' && (
                <div className="mb-5">
                  <div className="flex items-center justify-between mb-1.5">
                    <div className="font-hand text-xs text-brown/50 uppercase tracking-widest">Upload Photo</div>
                    {!googleToken ? (
                      <button 
                        onClick={onConnectGoogle}
                        className="font-hand text-[10px] text-blue-600 hover:underline flex items-center gap-1"
                      >
                        Connect Google Photos
                      </button>
                    ) : (
                      <div className="font-hand text-[10px] text-green-600">Connected to Photos</div>
                    )}
                  </div>

                  {googleToken && googlePhotos.length > 0 && (
                    <div className="mb-4">
                      <div className="font-hand text-[10px] text-brown/40 mb-2 italic">Select from your recent Google Photos:</div>
                      <div className="flex gap-2 overflow-x-auto pb-2">
                        {googlePhotos.map((photo) => (
                          <img 
                            key={photo.id}
                            src={photo.baseUrl}
                            onClick={() => setPhotoPreview(photo.baseUrl)}
                            className={`w-16 h-16 object-cover rounded-[2px] cursor-pointer border-2 transition-all ${photoPreview === photo.baseUrl ? 'border-dusty-rose scale-105' : 'border-transparent opacity-70 hover:opacity-100'}`}
                          />
                        ))}
                      </div>
                    </div>
                  )}

                  <label className="block border-2 border-dashed border-light-brown/20 rounded-[4px] p-7 text-center cursor-pointer hover:border-dusty-rose/50 hover:bg-dusty-rose/5 transition-all">
                    <input 
                      type="file" 
                      className="hidden" 
                      accept="image/*" 
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          const reader = new FileReader();
                          reader.onload = (ev) => setPhotoPreview(ev.target?.result as string);
                          reader.readAsDataURL(file);
                        }
                      }}
                    />
                    <Camera className="mx-auto mb-2 opacity-40" size={28} />
                    <div className="font-hand text-sm text-brown/40">Click to select a photo</div>
                  </label>
                  {photoPreview && <img src={photoPreview} className="mt-4 w-full h-32 object-cover rounded-[2px]" />}
                </div>
              )}

              {newType === 'voice' && (
                <div className="mb-6">
                  <div className="font-hand text-xs text-brown/50 uppercase tracking-widest mb-3">Record Voice Memory</div>
                  <div className="flex items-center gap-4 bg-parchment/30 p-6 rounded-2xl border border-light-brown/10">
                    {!audioUrl ? (
                      <button 
                        onClick={isRecording ? stopRecording : startRecording}
                        className={`w-16 h-16 rounded-full flex items-center justify-center transition-all shadow-lg ${isRecording ? 'bg-red-500 animate-pulse text-white' : 'bg-dark-brown text-cream hover:scale-105'}`}
                      >
                        {isRecording ? <Square size={24} /> : <Mic size={24} />}
                      </button>
                    ) : (
                      <div className="flex items-center gap-3 w-full">
                        <button className="w-12 h-12 rounded-full bg-sage text-white flex items-center justify-center shadow-md">
                          <Play size={20} fill="currentColor" />
                        </button>
                        <div className="flex-1 h-1 bg-brown/10 rounded-full overflow-hidden">
                          <div className="w-1/3 h-full bg-sage" />
                        </div>
                        <button onClick={deleteRecording} className="text-brown/30 hover:text-red-500 transition-colors">
                          <Trash2 size={18} />
                        </button>
                      </div>
                    )}
                    {!audioUrl && (
                      <div className="font-hand text-sm text-brown/60 italic">
                        {isRecording ? "Listening to your thoughts..." : "Tap to start recording"}
                      </div>
                    )}
                  </div>
                </div>
              )}

              {newType === 'music' && (
                <div className="mb-6 space-y-4">
                  <div className="flex items-center gap-4 border-b border-light-brown/10 pb-2">
                    <button 
                      onClick={() => setMusicSource('local')}
                      className={`font-hand text-xs uppercase tracking-widest pb-1 transition-all ${musicSource === 'local' ? 'text-dark-brown border-b-2 border-dark-brown' : 'text-brown/40 hover:text-brown/60'}`}
                    >
                      Local Library
                    </button>
                    <button 
                      onClick={() => setMusicSource('spotify')}
                      className={`font-hand text-xs uppercase tracking-widest pb-1 transition-all ${musicSource === 'spotify' ? 'text-green-600 border-b-2 border-green-600' : 'text-brown/40 hover:text-brown/60'}`}
                    >
                      Spotify
                    </button>
                  </div>

                  {musicSource === 'local' ? (
                    <div className="grid grid-cols-2 gap-2 max-h-48 overflow-y-auto pr-2">
                      {LOCAL_TRACKS.map(track => (
                        <button 
                          key={track.id}
                          onClick={() => {
                            setSelectedLocalTrack(track);
                            setNewSong(track.title);
                            setNewArtist(track.artist);
                            setPhotoPreview(track.albumArt);
                          }}
                          className={`flex items-center gap-3 p-2 rounded-xl transition-all ${selectedLocalTrack?.id === track.id ? 'bg-dusty-rose/20 border border-dusty-rose/30' : 'bg-black/5 hover:bg-black/10'}`}
                        >
                          <img src={track.albumArt} className="w-10 h-10 rounded shadow-sm" />
                          <div className="text-left min-w-0">
                            <div className="text-[11px] font-hand text-ink truncate">{track.title}</div>
                            <div className="text-[9px] text-brown/50 font-hand truncate">{track.artist}</div>
                          </div>
                        </button>
                      ))}
                    </div>
                  ) : (
                    <div className="space-y-3">
                      <div className="font-hand text-[10px] text-brown/50 uppercase tracking-widest flex items-center justify-between">
                        <span>Spotify Search</span>
                        {!spotifyToken ? (
                          <button 
                            onClick={onConnectSpotify}
                            className="text-[10px] text-green-600 hover:underline"
                          >
                            Connect Spotify
                          </button>
                        ) : (
                          <span className="text-[10px] text-green-600">Connected</span>
                        )}
                      </div>
                      {spotifyToken && (
                        <div className="space-y-3">
                          <div className="flex gap-2">
                            <input 
                              value={spotifySearchQuery}
                              onChange={(e) => setSpotifySearchQuery(e.target.value)}
                              onKeyDown={(e) => e.key === 'Enter' && searchSpotify(spotifySearchQuery)}
                              className="flex-1 bg-parchment/20 border border-light-brown/15 rounded-[3px] px-3 py-2 text-ink font-hand outline-none"
                              placeholder="Search for a song..."
                            />
                            <button 
                              onClick={() => searchSpotify(spotifySearchQuery)}
                              className="bg-dark-brown text-cream px-4 rounded-[3px] font-hand text-sm"
                            >
                              Search
                            </button>
                          </div>
                          {spotifyTracks.length > 0 && (
                            <div className="max-h-40 overflow-y-auto space-y-2 pr-2">
                              {spotifyTracks.map(track => (
                                <button 
                                  key={track.id}
                                  onClick={() => {
                                    setNewSong(track.name);
                                    setNewArtist(track.artists[0].name);
                                    setPhotoPreview(track.album.images[0].url);
                                  }}
                                  className={`w-full flex items-center gap-3 p-2 rounded-lg transition-all ${newSong === track.name ? 'bg-dusty-rose/20 border border-dusty-rose/30' : 'bg-black/5 hover:bg-black/10'}`}
                                >
                                  <img src={track.album.images[2].url} className="w-10 h-10 rounded shadow-sm" />
                                  <div className="text-left">
                                    <div className="text-sm font-hand text-ink truncate max-w-[200px]">{track.name}</div>
                                    <div className="text-[10px] text-brown/50 font-hand">{track.artists[0].name}</div>
                                  </div>
                                </button>
                              ))}
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  )}

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block font-hand text-[10px] text-brown/40 uppercase mb-1">Song Name</label>
                      <input 
                        value={newSong}
                        onChange={(e) => setNewSong(e.target.value)}
                        className="w-full bg-parchment/20 border border-light-brown/15 rounded-[3px] px-3 py-2 text-ink font-hand outline-none"
                        placeholder="e.g. Moonlight Sonata"
                      />
                    </div>
                    <div>
                      <label className="block font-hand text-[10px] text-brown/40 uppercase mb-1">Artist</label>
                      <input 
                        value={newArtist}
                        onChange={(e) => setNewArtist(e.target.value)}
                        className="w-full bg-parchment/20 border border-light-brown/15 rounded-[3px] px-3 py-2 text-ink font-hand outline-none"
                        placeholder="e.g. Beethoven"
                      />
                    </div>
                  </div>
                  <div className="bg-black/5 p-4 rounded-xl border border-dashed border-brown/10 flex items-center gap-4">
                    <div className="w-12 h-12 bg-zinc-200 rounded-lg flex items-center justify-center text-brown/20 overflow-hidden">
                      {photoPreview && newType === 'music' ? (
                        <img src={photoPreview} className="w-full h-full object-cover" />
                      ) : (
                        <Disc size={24} />
                      )}
                    </div>
                    <div className="font-hand text-xs text-brown/40 italic">
                      {newSong ? `Linking "${newSong}" to this memory...` : "Select a track to see preview"}
                    </div>
                  </div>
                </div>
              )}

              <div className="font-hand text-xs text-brown/50 uppercase tracking-widest mb-1.5">Title</div>
              <input 
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                className="w-full bg-parchment/20 border border-light-brown/15 rounded-[3px] px-3.5 py-2.5 text-ink font-hand text-lg outline-none focus:border-light-brown/40 mb-4" 
                placeholder="a golden afternoon in October…" 
              />

              <div className="font-hand text-xs text-brown/50 uppercase tracking-widest mb-1.5">Mood</div>
              <div className="flex gap-2 flex-wrap mb-4">
                {(['joy', 'nostalgic', 'love', 'peaceful', 'bittersweet', 'melancholic'] as const).map(m => (
                  <button
                    key={m}
                    onClick={() => setNewMood(m)}
                    className={`px-3 py-1 rounded-full font-hand text-xs border transition-all ${newMood === m ? 'bg-sage/20 border-sage text-moss' : 'bg-parchment/30 border-light-brown/20 text-brown/60'}`}
                  >
                    {m}
                  </button>
                ))}
              </div>

              <div className="font-hand text-xs text-brown/50 uppercase tracking-widest mb-1.5">Write about it</div>
              <textarea 
                value={newDesc}
                onChange={(e) => setNewDesc(e.target.value)}
                className="w-full bg-parchment/20 border border-light-brown/15 rounded-[3px] px-3.5 py-2.5 text-ink font-hand text-lg outline-none focus:border-light-brown/40 mb-4 resize-none" 
                rows={3}
                placeholder="What you felt, what you noticed…" 
              />

              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <div className="font-hand text-xs text-brown/50 uppercase tracking-widest mb-1.5">Location</div>
                  <input 
                    value={newLocation}
                    onChange={(e) => setNewLocation(e.target.value)}
                    className="w-full bg-parchment/20 border border-light-brown/15 rounded-[3px] px-3.5 py-2.5 text-ink font-hand outline-none"
                    placeholder="Where were you?"
                  />
                </div>
                <div>
                  <div className="font-hand text-xs text-brown/50 uppercase tracking-widest mb-1.5">Date</div>
                  <input 
                    type="date"
                    value={newDate}
                    onChange={(e) => setNewDate(e.target.value)}
                    className="w-full bg-parchment/20 border border-light-brown/15 rounded-[3px] px-3.5 py-2.5 text-ink font-hand outline-none"
                  />
                </div>
              </div>

              <button 
                onClick={handleSave}
                className="w-full py-3.5 bg-moss border border-light-brown text-cream font-hand text-lg tracking-widest rounded-[3px] hover:bg-dark-brown transition-all mt-4"
              >
                ✦ Place this memory in my Reminiq ✦
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Detail Panel */}
      <AnimatePresence>
        {selectedMemory && (
          <motion.div 
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 30, stiffness: 300 }}
            className="fixed top-0 right-0 bottom-0 w-full sm:w-[360px] bg-warm-white/95 backdrop-blur-2xl border-l border-light-brown/15 p-8 z-[6000] overflow-y-auto shadow-2xl"
          >
            <button onClick={() => setSelectedMemory(null)} className="absolute top-4 right-4 text-brown/30 hover:text-dusty-rose font-hand text-sm">✕ close</button>
            <div className="inline-block font-hand text-[10px] text-sage border border-sage/30 px-2.5 py-0.5 rounded-full uppercase tracking-widest mb-4">{selectedMemory.type}</div>
            
            {selectedMemory.emotion && (
              <div className="inline-block ml-2 font-hand text-[10px] bg-dusty-rose/10 text-dusty-rose border border-dusty-rose/20 px-2.5 py-0.5 rounded-full uppercase tracking-widest mb-4">
                {selectedMemory.emotion}
              </div>
            )}

            <div className="font-hand text-sm text-brown/50 mb-3">
              {new Date(selectedMemory.date).toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' })}
            </div>
            <h3 className="font-serif text-xl text-dark-brown italic mb-4 leading-tight">{selectedMemory.title}</h3>
            
            {selectedMemory.photoUrl && (
              <div className="bg-zinc-900 p-3 pb-10 shadow-2xl mb-6 relative rotate-1 rounded-sm group overflow-hidden">
                <img src={selectedMemory.photoUrl} className="w-full grayscale-[0.2] sepia-[0.1] group-hover:grayscale-0 transition-all duration-700" referrerPolicy="no-referrer" />
                <div className="absolute bottom-3 left-0 right-0 text-center font-hand text-[10px] text-white/40 uppercase tracking-widest">{selectedMemory.title}</div>
                <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent pointer-events-none" />
              </div>
            )}

            {selectedMemory.music && (
              <div className="mb-6">
                <MusicPlayer 
                  song={selectedMemory.music.song}
                  artist={selectedMemory.music.artist}
                  albumArt={selectedMemory.music.albumArt}
                  audioUrl={selectedMemory.musicUrl}
                  autoPlay={true}
                />
              </div>
            )}

            {selectedMemory.transcript && (
              <div className="mb-6 p-4 bg-parchment/30 rounded-2xl border border-light-brown/10">
                <div className="font-hand text-[10px] text-brown/40 uppercase tracking-widest mb-2 flex items-center gap-2">
                  <Mic size={10} /> Transcript
                </div>
                <p className="font-hand text-sm text-brown italic leading-relaxed">"{selectedMemory.transcript}"</p>
              </div>
            )}

            <p className="font-body text-sm text-ink/70 leading-relaxed mb-6">{selectedMemory.desc}</p>
            
            {selectedMemory.location && (
              <div className="flex items-center gap-2 font-hand text-xs text-moss mb-4">
                <MapPin size={12} /> {selectedMemory.location}
              </div>
            )}
            
            <div className="font-hand text-sm text-sage">✦ {selectedMemory.mood}</div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
