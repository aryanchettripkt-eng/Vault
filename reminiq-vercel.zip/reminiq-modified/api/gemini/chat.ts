import type { VercelRequest, VercelResponse } from '@vercel/node';

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: 'GEMINI_API_KEY not configured' });
  }

  const { message, memories } = req.body;
  if (!message) {
    return res.status(400).json({ error: 'Missing message' });
  }

  try {
    const memoryContext = (memories || []).map((m: any) => ({
      id: m.id,
      title: m.title,
      desc: m.desc,
      mood: m.mood,
      date: m.date
    }));

    const response = await fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=' + apiKey, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{
          parts: [{
            text: `You are a helpful AI assistant for a personal memory journal app called Reminiq.
Current Memories: ${JSON.stringify(memoryContext)}
User Request: "${message}"

If the user wants to "sort", "group", or "create an album" based on criteria, return a JSON object for a new album.

Response Format:
If creating an album:
{ "action": "create_album", "album": { "title": "Album Title", "memoryIds": ["id1", "id2"], "journalText": "A short poetic summary." }, "message": "A friendly message explaining what you did." }

If just chatting:
{ "action": "chat", "message": "Your response message here." }

Keep tone poetic, nostalgic, and warm. Respond ONLY with valid JSON, no markdown.`
          }]
        }],
        generationConfig: { responseMimeType: 'application/json' }
      })
    });

    const data = await response.json();
    const text = data.candidates?.[0]?.content?.parts?.[0]?.text || '{"action":"chat","message":"I had trouble recalling that."}';
    const result = JSON.parse(text.replace(/```json|```/g, '').trim());
    return res.status(200).json(result);
  } catch (error) {
    console.error('Gemini chat error:', error);
    return res.status(500).json({ action: 'chat', message: "I'm sorry, I had trouble recalling that. Could you try again?" });
  }
}
