import React, { useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronLeft, ChevronRight, MapPin, Calendar, Smile } from 'lucide-react';
import { Memory } from '../lib/gemini';

interface MemoryAlbumProps {
  memories: Memory[];
  onSelectMemory: (memory: Memory) => void;
}

const MOOD_COLORS: Record<string, { bg: string; text: string; dot: string }> = {
  nostalgic:   { bg: 'bg-faded-yellow/40',  text: 'text-brown',       dot: 'bg-faded-yellow' },
  bittersweet: { bg: 'bg-dusty-rose/30',    text: 'text-dark-brown',  dot: 'bg-dusty-rose' },
  joy:         { bg: 'bg-moss/20',          text: 'text-moss',        dot: 'bg-moss' },
  love:        { bg: 'bg-dusty-rose/40',    text: 'text-dark-brown',  dot: 'bg-dusty-rose' },
  peaceful:    { bg: 'bg-sage/20',          text: 'text-moss',        dot: 'bg-sage' },
  melancholic: { bg: 'bg-light-brown/20',   text: 'text-brown',       dot: 'bg-light-brown' },
};

const MOOD_EMOJI: Record<string, string> = {
  nostalgic: '🍂', bittersweet: '🌧', joy: '✨', love: '🌸', peaceful: '☁️', melancholic: '🎹',
};

type Direction = 'left' | 'right';

const variants = {
  enter: (dir: Direction) => ({
    rotateY: dir === 'right' ? 45 : -45,
    opacity: 0,
    scale: 0.92,
    z: -60,
  }),
  center: {
    rotateY: 0,
    opacity: 1,
    scale: 1,
    z: 0,
  },
  exit: (dir: Direction) => ({
    rotateY: dir === 'right' ? -45 : 45,
    opacity: 0,
    scale: 0.92,
    z: -60,
  }),
};

export default function MemoryAlbum({ memories, onSelectMemory }: MemoryAlbumProps) {
  const [page, setPage] = useState(0);
  const [direction, setDirection] = useState<Direction>('right');

  const total = memories.length;
  const current = memories[page];

  const go = useCallback((dir: Direction) => {
    setDirection(dir);
    setPage(p => dir === 'right' ? Math.min(p + 1, total - 1) : Math.max(p - 1, 0));
  }, [total]);

  if (!current) {
    return (
      <div className="flex items-center justify-center h-full min-h-[420px]">
        <div className="text-center">
          <div className="font-serif text-4xl text-brown/20 mb-3">✦</div>
          <p className="font-hand text-brown/40 text-lg">Your memories will appear here</p>
        </div>
      </div>
    );
  }

  const mood = MOOD_COLORS[current.mood] || MOOD_COLORS['nostalgic'];
  const emoji = MOOD_EMOJI[current.mood] || '✦';
  const dateStr = new Date(current.date).toLocaleDateString('en-US', { month: 'long', year: 'numeric' });

  return (
    <div className="flex flex-col items-center w-full select-none">
      {/* Album header */}
      <div className="flex items-center justify-between w-full max-w-md mb-4 px-1">
        <span className="font-hand text-sm text-brown/50 tracking-widest uppercase">Memory Album</span>
        <span className="font-hand text-xs text-brown/40">{page + 1} / {total}</span>
      </div>

      {/* Card stage with perspective */}
      <div
        className="relative w-full max-w-md"
        style={{ perspective: '900px', perspectiveOrigin: '50% 40%' }}
      >
        {/* Subtle shadow stack behind card */}
        <div
          className="absolute inset-x-4 bottom-0 h-full rounded-[3px] bg-parchment/60 border border-light-brown/10"
          style={{ transform: 'translateY(8px) scale(0.96)', zIndex: 0 }}
        />
        <div
          className="absolute inset-x-2 bottom-0 h-full rounded-[3px] bg-parchment/40 border border-light-brown/10"
          style={{ transform: 'translateY(4px) scale(0.98)', zIndex: 1 }}
        />

        {/* Main card */}
        <div className="relative" style={{ zIndex: 2 }}>
          <AnimatePresence custom={direction} mode="wait">
            <motion.div
              key={page}
              custom={direction}
              variants={variants}
              initial="enter"
              animate="center"
              exit="exit"
              transition={{ duration: 0.45, ease: [0.4, 0, 0.2, 1] }}
              style={{ transformStyle: 'preserve-3d', willChange: 'transform' }}
              className="bg-warm-white rounded-[3px] overflow-hidden shadow-[0_8px_40px_rgba(74,52,42,0.18),0_2px_8px_rgba(74,52,42,0.08)] border border-light-brown/20 cursor-pointer"
              onClick={() => onSelectMemory(current)}
            >
              {/* Photo */}
              <div className="relative w-full aspect-[4/3] overflow-hidden bg-parchment">
                {current.photoUrl ? (
                  <img
                    src={current.photoUrl}
                    alt={current.title}
                    className="w-full h-full object-cover"
                    style={{ filter: 'sepia(0.08) contrast(1.04)' }}
                    referrerPolicy="no-referrer"
                    draggable={false}
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center bg-parchment">
                    <span className="text-6xl opacity-20">✦</span>
                  </div>
                )}

                {/* Film strip holes top */}
                <div className="absolute top-0 left-0 right-0 flex justify-between px-3 py-1 pointer-events-none">
                  {Array.from({ length: 10 }).map((_, i) => (
                    <div key={i} className="w-3 h-3 rounded-[2px] bg-ink/30 border border-ink/20" />
                  ))}
                </div>

                {/* Mood badge */}
                <div className={`absolute top-6 right-3 px-2.5 py-1 rounded-full ${mood.bg} backdrop-blur-sm border border-white/20 flex items-center gap-1.5`}>
                  <span className="text-sm">{emoji}</span>
                  <span className={`font-hand text-xs capitalize ${mood.text}`}>{current.mood}</span>
                </div>

                {/* Gradient fade at bottom */}
                <div className="absolute bottom-0 left-0 right-0 h-24 bg-gradient-to-t from-warm-white/90 to-transparent pointer-events-none" />
              </div>

              {/* Text content */}
              <div className="px-6 pt-2 pb-6">
                <h2 className="font-serif text-2xl text-dark-brown leading-tight mb-2">{current.title}</h2>
                <p className="font-body text-sm text-brown/70 leading-relaxed line-clamp-3 mb-4">{current.desc}</p>

                <div className="flex items-center gap-4 pt-3 border-t border-light-brown/20">
                  {current.location && (
                    <div className="flex items-center gap-1.5 text-brown/50">
                      <MapPin size={12} />
                      <span className="font-hand text-xs">{current.location}</span>
                    </div>
                  )}
                  <div className="flex items-center gap-1.5 text-brown/40 ml-auto">
                    <Calendar size={12} />
                    <span className="font-hand text-xs">{dateStr}</span>
                  </div>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>

      {/* Navigation */}
      <div className="flex items-center gap-6 mt-6">
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={() => go('left')}
          disabled={page === 0}
          className="w-10 h-10 rounded-full border border-light-brown/30 bg-warm-white flex items-center justify-center text-brown/60 hover:text-dark-brown hover:border-light-brown/60 disabled:opacity-25 disabled:cursor-not-allowed transition-all shadow-sm"
        >
          <ChevronLeft size={18} />
        </motion.button>

        {/* Dot indicators */}
        <div className="flex gap-1.5 items-center">
          {memories.map((_, i) => (
            <button
              key={i}
              onClick={() => { setDirection(i > page ? 'right' : 'left'); setPage(i); }}
              className={`rounded-full transition-all duration-300 ${
                i === page
                  ? `w-5 h-2 ${mood.dot}`
                  : 'w-2 h-2 bg-light-brown/30 hover:bg-light-brown/60'
              }`}
            />
          ))}
        </div>

        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={() => go('right')}
          disabled={page === total - 1}
          className="w-10 h-10 rounded-full border border-light-brown/30 bg-warm-white flex items-center justify-center text-brown/60 hover:text-dark-brown hover:border-light-brown/60 disabled:opacity-25 disabled:cursor-not-allowed transition-all shadow-sm"
        >
          <ChevronRight size={18} />
        </motion.button>
      </div>

      {/* Tap hint */}
      <p className="font-hand text-xs text-brown/30 mt-3 tracking-wider">tap card to open memory</p>
    </div>
  );
}
