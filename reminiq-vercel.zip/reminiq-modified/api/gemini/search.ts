import type { VercelRequest, VercelResponse } from '@vercel/node';

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: 'GEMINI_API_KEY not configured' });
  }

  const { query, memories } = req.body;
  if (!query || !memories) {
    return res.status(400).json({ error: 'Missing query or memories' });
  }

  try {
    const memoryContext = memories.map((m: any) => ({
      id: m.id,
      title: m.title,
      desc: m.desc,
      type: m.type,
      mood: m.mood,
      location: m.location
    }));

    const response = await fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=' + apiKey, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{
          parts: [{
            text: `You are the librarian of "Reminiq". 
A user is searching for a memory with the query: "${query}".

Here are the memories in their vault:
${JSON.stringify(memoryContext)}

Find the most relevant memory. Return a JSON object with:
1. "intro": A poetic, nostalgic one-sentence introduction to the memory.
2. "memoryId": The ID of the matching memory, or null if no match.

Respond ONLY with valid JSON, no markdown.`
          }]
        }],
        generationConfig: { responseMimeType: 'application/json' }
      })
    });

    const data = await response.json();
    const text = data.candidates?.[0]?.content?.parts?.[0]?.text || '{"intro":"Could not search memories.","memoryId":null}';
    const result = JSON.parse(text.replace(/```json|```/g, '').trim());
    return res.status(200).json(result);
  } catch (error) {
    console.error('Gemini search error:', error);
    return res.status(500).json({ intro: "I couldn't find that specific moment.", memoryId: null });
  }
}
