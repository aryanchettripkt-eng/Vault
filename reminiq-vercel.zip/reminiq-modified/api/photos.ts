import type { VercelRequest, VercelResponse } from '@vercel/node';

export default async function handler(req: VercelRequest, res: VercelResponse) {
  const token = req.headers.authorization;
  if (!token) return res.status(401).json({ error: 'No token' });

  try {
    const response = await fetch('https://photoslibrary.googleapis.com/v1/mediaItems?pageSize=20', {
      headers: { Authorization: token as string }
    });
    const data = await response.json();
    res.json(data);
  } catch (error) {
    console.error('Fetch Photos Error:', error);
    res.status(500).json({ error: 'Failed to fetch photos' });
  }
}
