import type { VercelRequest, VercelResponse } from '@vercel/node';

export default async function handler(req: VercelRequest, res: VercelResponse) {
  const { code } = req.query;
  const appUrl = process.env.APP_URL || `https://${req.headers.host}`;
  const redirectUri = `${appUrl}/api/auth/spotify/callback`;

  try {
    const params = new URLSearchParams({
      code: code as string,
      client_id: process.env.SPOTIFY_CLIENT_ID!,
      client_secret: process.env.SPOTIFY_CLIENT_SECRET!,
      redirect_uri: redirectUri,
      grant_type: 'authorization_code',
    });

    const response = await fetch('https://accounts.spotify.com/api/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: params.toString()
    });
    const data = await response.json();
    const { access_token } = data;

    res.send(`<html><body><script>
      if (window.opener) {
        window.opener.postMessage({ type: 'SPOTIFY_AUTH_SUCCESS', token: '${access_token}' }, '*');
        window.close();
      } else { window.location.href = '/'; }
    </script><p>Authentication successful. This window should close automatically.</p></body></html>`);
  } catch (error) {
    console.error('Spotify OAuth Error:', error);
    res.status(500).send('Authentication failed');
  }
}
