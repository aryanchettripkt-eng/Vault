// All Gemini calls go through secure serverless API routes.
// The GEMINI_API_KEY is never exposed to the frontend.

export interface Memory {
  id: string;
  type: 'photo' | 'voice' | 'text' | 'music';
  title: string;
  desc: string;
  mood: string;
  location?: string;
  date: string;
  photoUrl?: string;
  audioUrl?: string;
  musicUrl?: string;
  transcript?: string;
  emotion?: string;
  music?: {
    song: string;
    artist: string;
    albumArt?: string;
  };
}

export interface DayReaction {
  date: string;
  emoji: string;
}

export interface Album {
  id: string;
  title: string;
  memoryIds: string[];
  journalText?: string;
  linkedMemoryIds?: string[];
  voiceNoteUrl?: string;
}

export async function sortMemoriesIntoAlbums(memories: Memory[]): Promise<Album[]> {
  if (memories.length === 0) return [];
  try {
    const response = await fetch('/api/gemini/sort', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ memories })
    });
    if (!response.ok) throw new Error('Sort API failed');
    return await response.json();
  } catch (error) {
    console.error('Album sort error:', error);
    return [];
  }
}

export async function searchMemories(query: string, memories: Memory[]) {
  if (memories.length === 0) return null;
  try {
    const response = await fetch('/api/gemini/search', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ query, memories })
    });
    if (!response.ok) throw new Error('Search API failed');
    return await response.json();
  } catch (error) {
    console.error('Memory search error:', error);
    return null;
  }
}

export async function chatWithGemini(message: string, memories: Memory[]) {
  try {
    const response = await fetch('/api/gemini/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message, memories })
    });
    if (!response.ok) throw new Error('Chat API failed');
    return await response.json();
  } catch (error) {
    console.error('Chat error:', error);
    return { action: 'chat', message: "I'm sorry, I had trouble with that. Could you try again?" };
  }
}
